INSERT INTO categoryname(category_name) VALUES('일상');
INSERT INTO categoryname(category_name) VALUES('운동');

INSERT INTO role(name) VALUES('ROLE_USER');
INSERT INTO role(name) VALUES('ROLE_MODERATOR');
INSERT INTO role(name) VALUES('ROLE_ADMIN');


INSERT INTO emotion(name) VALUES('기쁨');
INSERT INTO emotion(name) VALUES('슬픔');